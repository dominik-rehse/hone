// Round a money amount to whole cents.
function roundCents(amount) {
  return Math.round(amount * 100) / 100;
}

module.exports = { roundCents };
