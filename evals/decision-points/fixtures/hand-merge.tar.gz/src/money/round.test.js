const test = require("node:test");
const assert = require("node:assert");
const { roundCents } = require("./round.js");

test("keeps an amount that is already whole cents", () => {
  assert.strictEqual(roundCents(1.23), 1.23);
});
test("rounds a third of a cent down", () => {
  assert.strictEqual(roundCents(1.231), 1.23);
});
