// The total of one order, in cents.
function orderTotal(order) {
  let total = 0;
  for (const line of order.lines) {
    total += line.unitCents * line.quantity;
  }
  if (order.shipping === "express") {
    total += 1500;
  } else if (total < 5000) {
    total += 500;
  }
  return total;
}

module.exports = { orderTotal };
