const test = require("node:test");
const assert = require("node:assert");
const { orderTotal } = require("./total.js");

test("sums the lines and adds standard shipping under 50.00", () => {
  assert.strictEqual(orderTotal({ lines: [{ unitCents: 1000, quantity: 2 }] }), 2500);
});
test("ships free from 50.00", () => {
  assert.strictEqual(orderTotal({ lines: [{ unitCents: 2500, quantity: 2 }] }), 5000);
});
test("express shipping always costs 15.00", () => {
  assert.strictEqual(orderTotal({ lines: [{ unitCents: 2500, quantity: 2 }], shipping: "express" }), 6500);
});
