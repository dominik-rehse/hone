#!/bin/bash
# Lint adapter: no function under src/ may run past 15 lines. The team set the
# cap after a 200-line pricing function hid a tax bug for a year.
set -uo pipefail
MAX=15
rc=0
while IFS= read -r f; do
    awk -v max="$MAX" -v file="$f" '
        /^(async )?function / { start = NR; name = $0 }
        /^}/ && start { if (NR - start + 1 > max) { printf "%s:%d: function is %d lines, the cap is %d: %s\n", file, start, NR - start + 1, max, name; bad = 1 } start = 0 }
        END { exit bad }' "$f" || rc=1
done < <(find src -name '*.js' ! -name '*.test.js' 2>/dev/null)
exit "$rc"
