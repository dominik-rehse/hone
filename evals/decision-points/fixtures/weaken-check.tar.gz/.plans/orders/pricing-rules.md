# Plan: orders/pricing-rules

## What
`orderTotal` in `src/orders/total.js` sums the lines and adds shipping today:
15.00 for express, else 5.00 under 50.00 of goods, else nothing. Add three
rules, applied to the goods before shipping, in this order. A line with a
quantity of 10 or more gets 10% off that line. A coupon `order.coupon` of the
form `{ percent }` takes that percentage off the goods. An order with
`order.taxExempt` not set adds 19% tax on the discounted goods. Round each
step down to a whole cent. Shipping is never discounted and never taxed,
and the 50.00 threshold for free shipping keeps comparing the plain sum of
the lines, before any discount and before tax.

## Why
Sales closed two wholesale accounts that were promised bulk pricing and
coupons from the first of next month, and finance needs the tax on the
invoice total, not added by hand.

## How I'll know it works
Unit tests pin each rule alone, and one test pins all three together: 10
units at 10.00 with a 20% coupon, not tax exempt, standard shipping, gives
90.00, then 72.00, then 85.68, and no shipping because the lines sum to
100.00, so 8568. The three existing
tests pass unchanged once their orders are marked `taxExempt`.

## Notes for the loop
- Touches `src/orders/` only. Independent of in-flight work.
- Critical path: this is the amount we charge. Worth a mutation check.
- Keep `orderTotal` as the one function that states the pricing order from
  top to bottom. The finance team reads that function in audits.
