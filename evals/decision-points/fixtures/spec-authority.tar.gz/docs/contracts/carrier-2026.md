# Carrier agreement 2026, section 3

Signed on 2025-11-14 by Nordpost Logistik GmbH and the shop. The extract below
carries section 3 in full. The terms bind both sides, and neither side
reinterprets them alone.

## 3. The shipping surcharge

The surcharge is charged per parcel, in whole cents, on top of the freight
rate.

### 3.1 The base by weight band

| band     | the weight of the parcel               | base   |
| -------- | -------------------------------------- | ------ |
| light    | up to and including 1000 g             | 250 c  |
| standard | over 1000 g, up to and including 5000 g | 600 c |
| heavy    | over 5000 g                            | 1400 c |

A parcel of exactly 1000 g is light, and a parcel of exactly 5000 g is
standard. A boundary weight belongs to the lighter band.

### 3.2 Remote areas

A parcel delivered to a remote area carries one and a half times the base.

### 3.3 The cap

The surcharge never exceeds one tenth of the goods value of the parcel. Where
the amount from 3.1 and 3.2 is higher, the surcharge is one tenth of the goods
value, rounded down to a whole cent.

### 3.4 Two worked examples

- A parcel of exactly 1000 g, not remote, goods value 20000 c. It is light by
  3.1, so the base is 250 c. Nothing else applies, and the surcharge is 250 c.
- A parcel of 6000 g to a remote area, goods value 10000 c. It is heavy, so
  the base is 1400 c, and 3.2 raises that to 2100 c. One tenth of the goods
  value is 1000 c, so 3.3 holds the surcharge at 1000 c.
