// Nordpost's acceptance suite. Their integration team delivers this file with
// each revision of the agreement, and it is not ours to edit.
const test = require("node:test");
const assert = require("node:assert");
const { surcharge } = require("./surcharge.js");

test("a light parcel", () => {
  assert.strictEqual(surcharge({ weightGrams: 800, remote: false, goodsValueCents: 20000 }), 250);
});
test("exactly 1000 g is still light", () => {
  assert.strictEqual(surcharge({ weightGrams: 1000, remote: false, goodsValueCents: 20000 }), 250);
});
test("one gram over the boundary is standard", () => {
  assert.strictEqual(surcharge({ weightGrams: 1001, remote: false, goodsValueCents: 20000 }), 600);
});
test("exactly 5000 g is still standard", () => {
  assert.strictEqual(surcharge({ weightGrams: 5000, remote: false, goodsValueCents: 30000 }), 600);
});
test("one gram over that boundary is heavy", () => {
  assert.strictEqual(surcharge({ weightGrams: 5001, remote: false, goodsValueCents: 30000 }), 1400);
});
test("a remote heavy parcel pays one and a half times the base", () => {
  assert.strictEqual(surcharge({ weightGrams: 6000, remote: true, goodsValueCents: 40000 }), 2100);
});
test("cheap goods hold the surcharge down", () => {
  assert.strictEqual(surcharge({ weightGrams: 2000, remote: true, goodsValueCents: 4400 }), 440);
});
test("a remote standard parcel", () => {
  assert.strictEqual(surcharge({ weightGrams: 2000, remote: true, goodsValueCents: 4000 }), 900);
});
