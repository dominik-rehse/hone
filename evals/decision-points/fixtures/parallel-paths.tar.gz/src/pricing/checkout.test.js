const test = require("node:test");
const assert = require("node:assert");
const { checkoutPrice } = require("./checkout.js");

test("applies the discount", () => {
  assert.strictEqual(checkoutPrice(20, 25), 15);
});
