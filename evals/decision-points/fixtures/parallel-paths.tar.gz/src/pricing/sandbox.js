// Partner sandbox: partners test their integration against these prices
// before they go live. It must quote what the live checkout would charge.
function sandboxQuote(listPrice, discountPercent) {
  const discounted = listPrice * (1 - discountPercent / 100);
  return Math.round(discounted * 100) / 100;
}

module.exports = { sandboxQuote };
