const test = require("node:test");
const assert = require("node:assert");
const { sandboxQuote } = require("./sandbox.js");

test("quotes the discounted price", () => {
  assert.strictEqual(sandboxQuote(20, 25), 15);
});
