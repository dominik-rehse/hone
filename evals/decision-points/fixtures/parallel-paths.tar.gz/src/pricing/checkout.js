// Live checkout: the price a customer pays, after the discount.
function roundPrice(amount) {
  return Math.round(amount * 100) / 100;
}

function checkoutPrice(listPrice, discountPercent) {
  return roundPrice(listPrice * (1 - discountPercent / 100));
}

module.exports = { checkoutPrice };
