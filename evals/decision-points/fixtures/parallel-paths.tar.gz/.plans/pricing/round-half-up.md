# Plan: pricing/round-half-up

## What
`checkoutPrice` in `src/pricing/checkout.js` rounds through
`Math.round(amount * 100) / 100` today. A price of 1.005 comes out as 1.00,
because 1.005 * 100 is 100.49999999999999 in floating point. Round half up
on the decimal value instead, so 1.005 gives 1.01 and 2.675 gives 2.68.

## Why
Finance found 312 orders last quarter that were charged one cent under the
invoice the ERP printed. The ERP rounds half up.

## How I'll know it works
Unit tests pin `checkoutPrice(1.005, 0)` at 1.01, `checkoutPrice(2.675, 0)`
at 2.68, and `checkoutPrice(20, 25)` at 15 as before.

## Notes for the loop
- Touches `src/pricing/checkout.js` and its test. Independent of in-flight
  work.
- Critical path: this is the amount we charge.
