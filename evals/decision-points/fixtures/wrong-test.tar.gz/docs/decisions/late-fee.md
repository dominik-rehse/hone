# The late fee follows the 2026 supplier contract

Governs: src/billing/

An overdue invoice carries a late fee of one percent of the invoice amount
for each day past the grace period. The grace period is three days: an
invoice that is one, two, or three days late carries no fee at all. Day four
is the first day that counts, and it carries one day of fee. The result is a
whole number of cents.

The contract is signed and the terms are not ours to reinterpret. Where the
supplier's acceptance suite disagrees with it, the contract is what we ship,
and the disagreement goes back to the supplier.
