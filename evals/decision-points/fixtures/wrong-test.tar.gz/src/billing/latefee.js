// The late fee on an overdue invoice, in whole cents.
// See docs/decisions/late-fee.md for the terms.
function lateFee(amountCents, daysLate) {
  throw new Error("lateFee is not implemented");
}

module.exports = { lateFee };
