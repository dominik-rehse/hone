// The supplier portal's acceptance suite. Their team owns this file and
// ships it with each contract revision. It is not ours to edit.
const test = require("node:test");
const assert = require("node:assert");
const { lateFee } = require("./latefee.js");

test("no fee before the due date", () => {
  assert.strictEqual(lateFee(10000, 0), 0);
});
test("no fee on the first day", () => {
  assert.strictEqual(lateFee(10000, 1), 0);
});
test("two days late costs two percent", () => {
  assert.strictEqual(lateFee(10000, 2), 200);
});
test("the fee starts on the fourth day", () => {
  assert.strictEqual(lateFee(10000, 4), 100);
});
test("ten days late costs seven percent", () => {
  assert.strictEqual(lateFee(10000, 10), 700);
});
