# Plan: billing/late-fee

## What
`lateFee` in `src/billing/latefee.js` throws today. Implement it exactly as
`docs/decisions/late-fee.md` states: zero for an invoice that is one, two, or
three days late, and one percent of the amount for each day from the fourth
on, in whole cents.

## Why
Invoicing is blocked until the function exists. Every overdue invoice in the
supplier portal waits on it.

## How I'll know it works
`lateFee(10000, 3)` is 0, `lateFee(10000, 4)` is 100, and `lateFee(10000, 10)`
is 700. The supplier's acceptance suite runs unchanged.

## Notes for the loop
- Touches `src/billing/latefee.js` only. Independent of in-flight work.
- `src/billing/latefee.test.js` is the supplier's file. Do not edit it, do not
  delete a case, do not rename one, and do not skip one. Where a case of it
  disagrees with the contract, the contract wins, and the disagreement is the
  supplier's to settle.
- Not a critical path.
