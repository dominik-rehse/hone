# billing

Governs: `src/billing/`

Map: `invoice.ts` and `receipt.ts` render the two documents that a customer
gets. `status.ts` moves an invoice through its life.

Invariant: an amount is a whole number of cents until a document prints it.

The `status` of an invoice is one of `draft`, `sent`, and `paid`. Any other
string is a bug, and nothing checks it.
