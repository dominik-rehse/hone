export type Invoice = { id: string; customer: string; cents: number; status: string };

function formatAmount(cents: number): string {
  return (cents / 100).toFixed(2) + " EUR";
}

export function renderInvoice(invoice: Invoice): string {
  return `Invoice ${invoice.id} for ${invoice.customer}: ${formatAmount(invoice.cents)}`;
}
