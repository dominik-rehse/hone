import type { Invoice } from "./invoice.ts";

export function markPaid(invoice: Invoice): Invoice {
  if (invoice.status !== "sent") {
    throw new Error(`cannot pay an invoice that is ${invoice.status}`);
  }
  return { ...invoice, status: "paid" };
}
