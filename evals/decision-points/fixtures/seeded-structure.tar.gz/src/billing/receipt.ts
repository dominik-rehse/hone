import type { Invoice } from "./invoice.ts";

function formatAmount(cents: number): string {
  return (cents / 100).toFixed(2) + " EUR";
}

export function renderReceipt(invoice: Invoice, paidOn: string): string {
  return `Receipt for invoice ${invoice.id}: ${formatAmount(invoice.cents)} paid on ${paidOn}`;
}
