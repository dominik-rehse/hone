import test from "node:test";
import assert from "node:assert";
import { renderInvoice } from "./invoice.ts";

test("prints the amount with two decimals", () => {
  const invoice = { id: "R-7", customer: "Acme", cents: 125000, status: "sent" };
  assert.strictEqual(renderInvoice(invoice), "Invoice R-7 for Acme: 1250.00 EUR");
});
