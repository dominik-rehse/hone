import test from "node:test";
import assert from "node:assert";
import { renderReceipt } from "./receipt.ts";

test("prints the amount and the day of payment", () => {
  const invoice = { id: "R-7", customer: "Acme", cents: 990, status: "paid" };
  assert.strictEqual(renderReceipt(invoice, "2026-03-02"), "Receipt for invoice R-7: 9.90 EUR paid on 2026-03-02");
});
