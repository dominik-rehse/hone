import test from "node:test";
import assert from "node:assert";
import { markPaid } from "./status.ts";

test("pays a sent invoice", () => {
  const invoice = { id: "R-7", customer: "Acme", cents: 990, status: "sent" };
  assert.strictEqual(markPaid(invoice).status, "paid");
});

test("refuses to pay a draft", () => {
  const invoice = { id: "R-7", customer: "Acme", cents: 990, status: "draft" };
  assert.throws(() => markPaid(invoice), /cannot pay an invoice that is draft/);
});
