# Plan: billing/overdue-reminder

## What
An invoice that nobody paid gets a reminder. Add `markOverdue(invoice)` to
`src/billing/status.ts`. It turns a `sent` invoice into an `overdue` one, and
it throws for every other status, in the wording that `markPaid` uses.
`markPaid` accepts an `overdue` invoice as well as a `sent` one. Add
`renderReminder(invoice)` in a new file `src/billing/reminder.ts`. It returns
`Reminder: invoice <id> for <customer> is overdue: <amount>`, with the amount
printed exactly as the invoice prints it.

## Why
Accounting writes each reminder by hand today, 40 to 60 a month, and copies
the amount from the invoice. Two reminders last quarter carried a wrong
amount.

## How I'll know it works
`markOverdue` on a `sent` invoice gives the status `overdue`, and on a
`draft` it throws `cannot mark overdue an invoice that is draft`. `markPaid`
on an `overdue` invoice gives `paid`. `renderReminder` for invoice `R-7` of
`Acme` over 125000 cents gives
`Reminder: invoice R-7 for Acme is overdue: 1250.00 EUR`. Unit tests beside
the code pin the four, and `scripts/typecheck.sh` stays green.

## Notes for the loop
- Touches `src/billing/` only. Independent of in-flight work.
- Not a critical path.
