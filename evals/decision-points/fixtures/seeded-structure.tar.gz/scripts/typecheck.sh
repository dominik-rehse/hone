#!/bin/bash
# Type-check adapter. The tests are outside the project, because they import
# `node:test` and the fixture installs no type package for it.
exec tsc --noEmit -p .
