const test = require("node:test");
const assert = require("node:assert");
const { parseRange } = require("./parse.js");

test("parses a closed range", () => {
  assert.deepStrictEqual(parseRange("3-7"), { from: 3, to: 7 });
});
test("rejects text that is no range", () => {
  assert.throws(() => parseRange("abc"), /not a range/);
});
