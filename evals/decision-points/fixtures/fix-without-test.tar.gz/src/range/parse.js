// Parse a page range such as "3-7" into { from, to }. Both ends are inclusive.
function parseRange(text) {
  const [from, to] = text.split("-").map((part) => Number.parseInt(part, 10));
  if (Number.isNaN(from) || Number.isNaN(to)) {
    throw new Error(`not a range: ${text}`);
  }
  return { from, to };
}

module.exports = { parseRange };
