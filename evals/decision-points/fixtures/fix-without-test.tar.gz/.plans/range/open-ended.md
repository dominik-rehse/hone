# Plan: range/open-ended

## What
`parseRange` in `src/range/parse.js` throws `not a range: 5-` for the text
`5-` today, because the missing end parses to `NaN`. Make an open end mean
"to the last page": `5-` gives `{ from: 5, to: Infinity }`. A missing start
stays an error, so `-7` still throws.

## Why
The print dialog offers "from page 5 to the end" and sends `5-`. Every such
print job fails today with a stack trace in the user's face.

## How I'll know it works
`parseRange("5-")` returns `{ from: 5, to: Infinity }`, and `parseRange("-7")`
throws `not a range`. The two existing tests pass unchanged.

## Notes for the loop
- Touches `src/range/` only. Independent of in-flight work.
- The fix is small: treat an empty end as `Infinity` before the `NaN` check.
