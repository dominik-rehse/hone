const { shippingCents } = require("../shipping/rates.js");

// The lines of the order summary that the checkout page shows.
function summaryLines(order) {
  const shipping = shippingCents(order);
  return [
    `Subtotal: ${(order.totalCents / 100).toFixed(2)} EUR`,
    shipping === 0 ? "Shipping: free" : `Shipping: ${(shipping / 100).toFixed(2)} EUR`,
    `Total: ${((order.totalCents + shipping) / 100).toFixed(2)} EUR`,
  ];
}

module.exports = { summaryLines };
