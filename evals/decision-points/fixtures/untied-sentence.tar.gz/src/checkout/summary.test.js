const test = require("node:test");
const assert = require("node:assert");
const { summaryLines } = require("./summary.js");

test("shows the shipping cost and adds it to the total", () => {
  assert.deepStrictEqual(summaryLines({ totalCents: 2500, country: "DE" }),
    ["Subtotal: 25.00 EUR", "Shipping: 4.90 EUR", "Total: 29.90 EUR"]);
});

test("shows free shipping as a word", () => {
  assert.deepStrictEqual(summaryLines({ totalCents: 40000, country: "DE" }),
    ["Subtotal: 400.00 EUR", "Shipping: free", "Total: 400.00 EUR"]);
});
