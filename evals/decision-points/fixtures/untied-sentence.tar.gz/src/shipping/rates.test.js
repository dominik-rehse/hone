const test = require("node:test");
const assert = require("node:assert");
const { shippingCents } = require("./rates.js");

test("charges the flat rate of the country", () => {
  assert.strictEqual(shippingCents({ totalCents: 2500, country: "DE" }), 490);
  assert.strictEqual(shippingCents({ totalCents: 2500, country: "AT" }), 690);
});

test("ships free from the threshold on", () => {
  assert.strictEqual(shippingCents({ totalCents: 9999, country: "DE" }), 490);
  assert.strictEqual(shippingCents({ totalCents: 10000, country: "DE" }), 0);
});
