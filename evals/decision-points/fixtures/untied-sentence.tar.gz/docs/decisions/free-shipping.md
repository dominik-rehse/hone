# Free shipping from a threshold, and no coupon

We give free shipping from an order total on, and we send no free-shipping
coupon. A coupon needs a code field at checkout, and support answered 40
questions a month about codes that had expired. A threshold needs no input
from the customer. The threshold is 100.00 EUR.
