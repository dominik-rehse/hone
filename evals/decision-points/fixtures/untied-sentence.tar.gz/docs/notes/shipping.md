# shipping

Governs: `src/shipping/`

Map: `rates.js` holds the whole rate table and the one function that reads it.

Invariant: a rate is a whole number of cents. Nothing in this area rounds.
