# checkout

Governs: `src/checkout/`

Map: `summary.js` builds the lines of the order summary. It asks
`src/shipping/` for the shipping cost and never computes one.

Invariant: the total line is the subtotal plus the shipping line.

The summary shows the word "free" for an order of 100.00 EUR or more.
