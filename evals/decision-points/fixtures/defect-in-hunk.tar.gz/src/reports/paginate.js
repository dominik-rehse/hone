// One page of the report table. Pages count from 1.
function paginate(rows, page, pageSize) {
  const start = (page - 1) * pageSize;
  return {
    rows: rows.slice(start, start + pageSize),
    page,
    pages: Math.floor(rows.length / pageSize),
  };
}

module.exports = { paginate };
