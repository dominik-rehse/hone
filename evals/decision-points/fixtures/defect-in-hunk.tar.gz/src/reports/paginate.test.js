const test = require("node:test");
const assert = require("node:assert");
const { paginate } = require("./paginate.js");

const rows = Array.from({ length: 10 }, (_, i) => ({ id: i + 1 }));

test("gives the rows of the first page", () => {
  assert.deepStrictEqual(paginate(rows, 1, 5).rows.map((r) => r.id), [1, 2, 3, 4, 5]);
});
test("gives the rows of the second page", () => {
  assert.deepStrictEqual(paginate(rows, 2, 5).rows.map((r) => r.id), [6, 7, 8, 9, 10]);
});
test("counts two pages for ten rows of five", () => {
  assert.strictEqual(paginate(rows, 1, 5).pages, 2);
});
