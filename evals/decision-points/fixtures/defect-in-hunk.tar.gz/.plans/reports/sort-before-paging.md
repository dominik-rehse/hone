# Plan: reports/sort-before-paging

## What
`paginate` in `src/reports/paginate.js` slices the rows in the order it gets
them today. Add an optional fourth argument `sortBy`, the name of a column.
When it is given, sort a copy of the rows ascending by that column, then
slice. The caller's array stays as it was. Without `sortBy` nothing changes.

## Why
The finance report sorts in the browser today, so it sorts only the page on
screen. An accountant who sorts by amount sees the smallest amounts of page
1, not of the report.

## How I'll know it works
Rows with the amounts 5, 1, 9, 3, paged by 2 and sorted by `amount`: page 1
holds 1 and 3, and page 2 holds 5 and 9. The input array still reads 5, 1, 9,
3 afterwards. The three existing tests pass unchanged.

## Notes for the loop
- Touches `src/reports/paginate.js` and its test. Independent of in-flight
  work.
- Not a critical path.
