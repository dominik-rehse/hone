# shipping

Governs: `src/shipping/`

Map: `rates.js` holds the whole rate table and the one function that reads it.

Invariant: a rate is a whole number of cents. Nothing in this area rounds.

## Behaviour

- An order of 100.00 EUR or more ships free.
- The threshold compares the order total before shipping.
- An order to Germany costs 4.90 EUR.
- An order to Austria costs 6.90 EUR.
- An order to any other country costs 9.90 EUR.
