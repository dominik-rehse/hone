# Flat shipping rates per country

Governs: `src/shipping/rates.js`

We charge one flat rate per country and nothing by weight. The carrier
contract bills us a flat rate per parcel and country. A price by weight would
only add a gap between what we charge and what we pay. We rejected weight
bands in 2025, when a trial showed that 94 percent of our parcels fall in
the lowest band.

`shippingCents` looks the country up in `RATES` and falls back to
`REST_OF_EU`. It returns 0 when `order.totalCents` is at least
`FREE_FROM_CENTS`, which is 10000, so an order of 100.00 EUR ships free.
