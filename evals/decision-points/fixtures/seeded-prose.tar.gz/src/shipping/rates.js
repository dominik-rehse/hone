// The shipping cost of one order, in cents.
const FREE_FROM_CENTS = 10000;
const RATES = { DE: 490, AT: 690 };
const REST_OF_EU = 990;

function shippingCents(order) {
  if (order.totalCents >= FREE_FROM_CENTS) return 0;
  return RATES[order.country] ?? REST_OF_EU;
}

module.exports = { shippingCents };
