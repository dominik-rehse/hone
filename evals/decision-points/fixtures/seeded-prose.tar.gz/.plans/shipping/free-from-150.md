# Plan: shipping/free-from-150

## What
`shippingCents` in `src/shipping/rates.js` ships an order free from 100.00
EUR on today. Raise that threshold to 150.00 EUR. An order of 149.99 EUR
pays the flat rate of its country, and an order of 150.00 EUR pays nothing.
The flat rates stay as they are.

## Why
The carrier raised its parcel prices by 11 percent in August. Finance
reports that free shipping between 100 and 150 EUR now loses money on two
orders out of three.

## How I'll know it works
`shippingCents({ totalCents: 14999, country: "DE" })` is 490, and with
`totalCents: 15000` it is 0. The unit test of the threshold pins both. The
two tests of the flat rates pass unchanged.

## Notes for the loop
- Touches `src/shipping/` only. Independent of in-flight work.
- Not a critical path.
