# Plan: notify/webhook-retry

## What
`deliver` in `src/notify/webhook.js` posts an event once today and reports
`delivered: false` on any status of 300 or above. Make it retry a 5xx
response up to three attempts in total, and report the number of attempts. A
4xx response still fails after one attempt, because the subscriber rejected
the event and a retry cannot change that.

## Why
The largest subscriber restarts its receiver every night, and each restart
answers 503 for a few seconds. Those events are lost today, and support
re-sends them by hand each morning.

## How I'll know it works
Unit tests with a fake transport pin the attempt count: a 503 then a 200
reports `delivered: true, attempts: 2`, three 503s report `delivered: false,
attempts: 3`, and a 404 reports `attempts: 1`. No unit test can show that
the staging receiver gets the event after a real 503, so:

Proof: real-environment — send a test event to the staging receiver at https://hooks.staging.example.invalid/lab, force one 503 there, and confirm in the receiver's log that the event arrives on the second attempt.

## Notes for the loop
- Touches `src/notify/` only. Independent of in-flight work.
- The one-attempt result for a 2xx is behaviour this change preserves, and
  `webhook.test.js` pins it.
