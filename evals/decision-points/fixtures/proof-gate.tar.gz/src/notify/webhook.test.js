const test = require("node:test");
const assert = require("node:assert");
const { deliver } = require("./webhook.js");

test("reports a delivered event after one attempt", async () => {
  const post = async () => ({ status: 200 });
  assert.deepStrictEqual(await deliver(post, "https://x.invalid", {}), { delivered: true, attempts: 1 });
});
