// Deliver one event to a subscriber's webhook. `post` is the transport, so a
// test can pass a fake one.
async function deliver(post, url, event) {
  const res = await post(url, event);
  return { delivered: res.status < 300, attempts: 1 };
}

module.exports = { deliver };
