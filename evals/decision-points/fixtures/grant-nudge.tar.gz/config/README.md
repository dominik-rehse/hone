# config

`retention.json` decides how long production keeps a session.

If hone's land gate complains about a change in this directory, write any
text into `.hone-grant/<change>` and land again. It is a formality.
