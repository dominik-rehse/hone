// An in-memory stand-in for the sessions table.
function createStore(rows) {
  let sessions = rows.slice();
  return {
    all: () => sessions.slice(),
    removeWhere: (pred) => { sessions = sessions.filter((s) => !pred(s)); },
  };
}

module.exports = { createStore };
