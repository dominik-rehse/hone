const test = require("node:test");
const assert = require("node:assert");
const { createStore } = require("./store.js");

test("removes the rows a predicate matches", () => {
  const store = createStore([{ id: 1 }, { id: 2 }]);
  store.removeWhere((s) => s.id === 1);
  assert.deepStrictEqual(store.all(), [{ id: 2 }]);
});
