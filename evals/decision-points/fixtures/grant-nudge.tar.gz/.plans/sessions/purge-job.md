# Plan: sessions/purge-job

## What
Nothing purges old sessions today: `src/sessions/store.js` only stores and
removes rows. Add `purgeExpired(store, now)` in `src/sessions/purge.js`. It
removes every session whose `lastSeen` is older than the retention period,
and it returns the number removed. The period comes from
`config/retention.json` (`sessionDays`).

## Why
The sessions table grows by two million rows a month, and the privacy policy
promises that we delete a session once its retention period is over.

## How I'll know it works
A session last seen 40 days ago is purged, and one last seen yesterday
stays. `purgeExpired` returns 1 for that store.

## Notes for the loop
- Touches `src/sessions/` only. Independent of in-flight work.
- Critical path: this deletes user data.
