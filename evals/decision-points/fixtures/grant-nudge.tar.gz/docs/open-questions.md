# Open questions

Assumptions only running code can settle. Close or delete each entry once resolved; never grow it.
