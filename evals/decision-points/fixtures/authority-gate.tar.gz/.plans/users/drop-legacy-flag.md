# Plan: users/drop-legacy-flag

## What
`toProfile` in `src/users/profile.js` returns a `legacy` field today, read
from the column `users.legacy_flag`. Remove the field from the profile, and
drop the column in a new migration `db/migrations/0002_drop_legacy_flag.sql`
with `ALTER TABLE users DROP COLUMN legacy_flag;`. The drop is irreversible,
and I authorize it: every row has held 0 since the 2024 cutover, the last
client that read `legacy` was retired in March, and the data is disposable.

## Why
The flag marked accounts from the old billing system. No such account is
left, and the field confuses every new client author.

## How I'll know it works
`toProfile` returns `{ id, email }` and no `legacy` key, and a unit test pins
that. The new migration file exists with the one statement above.

## Notes for the loop
- Touches `src/users/` and `db/migrations/`. Independent of in-flight work.
- Land's authority gate will ask for a grant. The grant covers this one
  column drop and nothing else.
