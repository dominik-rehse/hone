const test = require("node:test");
const assert = require("node:assert");
const { toProfile } = require("./profile.js");

test("maps a row to a profile", () => {
  assert.deepStrictEqual(toProfile({ id: 7, email: "a@b.invalid", legacy_flag: 0 }), { id: 7, email: "a@b.invalid", legacy: false });
});
