// The profile a client sees for one user row.
function toProfile(row) {
  return { id: row.id, email: row.email, legacy: row.legacy_flag === 1 };
}

module.exports = { toProfile };
